Disclaimer:
The use of this code is at your own risk. Of course, we do made every effort to ensure 
that the reference files are free of bugs and issues. We also tested the design on FPGAs 
to make sure that it actually works. 
